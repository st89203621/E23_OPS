#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
用户流量统计脚本
从IAM配置文件中读取IP地址，调用API获取用户流量数据，
合并处理后输出到Excel文件
"""

import os
import sys
import json
import logging
import hashlib
import random
import string
import time
from datetime import datetime
from typing import List, Dict, Any, Optional

# 尝试导入依赖包，如果失败则给出提示
try:
    import requests
except ImportError:
    print("❌ 缺少 requests 包，请运行: pip install requests")
    sys.exit(1)

try:
    import pandas as pd
except ImportError:
    print("❌ 缺少 pandas 包，请运行: pip install pandas")
    sys.exit(1)

try:
    import openpyxl
except ImportError:
    print("❌ 缺少 openpyxl 包，请运行: pip install openpyxl")
    sys.exit(1)

import config


class UserFlowStatsProcessor:
    """用户流量统计处理器"""
    
    def __init__(self):
        """初始化处理器"""
        self.setup_logging()
        self.logger = logging.getLogger(__name__)
        self.all_user_data = []
        self.station_names = {}  # 存储局点名称映射
        self.used_randoms = set()  # 存储已使用的random值，防止重复
        
    def setup_logging(self):
        """设置日志"""
        logging.basicConfig(
            level=getattr(logging, config.LOG_LEVEL),
            format=config.LOG_FORMAT,
            handlers=[
                logging.StreamHandler(sys.stdout),
                logging.FileHandler(
                    os.path.join(config.LOGS_DIR, f"user_flow_stats_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"),
                    encoding='utf-8'
                )
            ]
        )

    def generate_random_string(self) -> str:
        """
        生成唯一的随机字符串用于API认证

        Returns:
            随机字符串
        """
        max_attempts = 100  # 最大尝试次数，防止无限循环

        for _ in range(max_attempts):
            # 生成随机字符串：时间戳 + 随机字符
            timestamp = str(int(time.time() * 1000))  # 毫秒时间戳
            random_chars = ''.join(random.choices(
                string.ascii_letters + string.digits,
                k=config.RANDOM_LENGTH - len(timestamp)
            ))
            random_str = timestamp + random_chars

            # 确保不重复
            if random_str not in self.used_randoms:
                self.used_randoms.add(random_str)
                self.logger.debug(f"生成random字符串: {random_str}")
                return random_str

        # 如果尝试多次仍然重复，使用UUID确保唯一性
        import uuid
        random_str = str(uuid.uuid4()).replace('-', '')[:config.RANDOM_LENGTH]
        self.used_randoms.add(random_str)
        self.logger.debug(f"使用UUID生成random字符串: {random_str}")
        return random_str

    def calculate_md5(self, shared_secret: str, random_str: str) -> str:
        """
        计算MD5认证值

        Args:
            shared_secret: 共享密钥
            random_str: 随机字符串

        Returns:
            MD5值
        """
        # 按照规则拼接：共享密钥 + random
        combined_str = shared_secret + random_str

        # 计算MD5
        md5_hash = hashlib.md5(combined_str.encode('utf-8')).hexdigest()

        self.logger.debug(f"MD5计算: '{shared_secret}' + '{random_str}' = '{combined_str}' -> {md5_hash}")
        return md5_hash

    def get_auth_params(self) -> Dict[str, str]:
        """
        获取API认证参数

        Returns:
            包含random和md5的认证参数字典
        """
        random_str = self.generate_random_string()
        md5_value = self.calculate_md5(config.SHARED_SECRET, random_str)

        auth_params = {
            "random": random_str,
            "md5": md5_value
        }

        self.logger.debug(f"生成认证参数: {auth_params}")
        return auth_params
    
    def read_excel_config(self, file_path: str) -> List[Dict[str, str]]:
        """
        读取Excel配置文件，提取局点名称和IP地址
        
        Args:
            file_path: Excel文件路径
            
        Returns:
            包含局点名称和IP地址的字典列表
        """
        try:
            self.logger.info(f"开始读取配置文件: {file_path}")
            
            # 读取Excel文件
            df = pd.read_excel(file_path, engine='openpyxl')
            
            # 检查是否有足够的列
            if df.shape[1] < 2:
                raise ValueError("Excel文件至少需要包含2列数据（局点名称和IP地址）")
            
            # 提取第一列（局点名称）和第二列（IP地址）
            station_column = df.iloc[:, 0]  # 第一列
            ip_column = df.iloc[:, 1]       # 第二列
            
            config_data = []
            for i, (station, ip) in enumerate(zip(station_column, ip_column)):
                # 跳过空值
                if pd.isna(station) or pd.isna(ip):
                    continue
                    
                station_str = str(station).strip()
                ip_str = str(ip).strip()
                
                if station_str and ip_str:
                    config_data.append({
                        'station_name': station_str,
                        'ip_address': ip_str
                    })
                    # 存储IP到局点名称的映射
                    self.station_names[ip_str] = station_str
            
            self.logger.info(f"成功读取 {len(config_data)} 条配置记录")
            return config_data
            
        except Exception as e:
            self.logger.error(f"读取Excel配置文件失败: {str(e)}")
            raise
    
    def call_api(self, ip_address: str) -> Optional[List[Dict[str, Any]]]:
        """
        调用API获取用户流量数据

        Args:
            ip_address: 设备IP地址

        Returns:
            用户数据列表，失败时返回None
        """
        for attempt in range(config.MAX_RETRIES):
            try:
                self.logger.debug(f"向 {ip_address} 发送API请求 (尝试 {attempt + 1}/{config.MAX_RETRIES})")

                # 获取认证参数
                auth_params = self.get_auth_params()

                # 构建URL，将认证参数放在查询参数中
                url = f"http://{ip_address}:{config.API_PORT}{config.API_ENDPOINT}?_method=GET&random={auth_params['random']}&md5={auth_params['md5']}"

                # 构建请求体，只包含业务参数
                request_payload = config.API_PAYLOAD

                self.logger.debug(f"请求URL: {url}")
                self.logger.debug(f"请求体: {json.dumps(request_payload, ensure_ascii=False)}")

                response = requests.post(
                    url,
                    headers=config.API_HEADERS,
                    json=request_payload,
                    timeout=config.REQUEST_TIMEOUT
                )
                
                if response.status_code == 200:
                    try:
                        data = response.json()
                        if 'data' in data and isinstance(data['data'], list):
                            user_data = data['data']
                            self.logger.info(f"从 {ip_address} 获取到 {len(user_data)} 条用户数据")

                            # 为每条数据添加来源信息
                            for user in user_data:
                                user['source_ip'] = ip_address
                                user['station_name'] = self.station_names.get(ip_address, ip_address)

                            return user_data
                        else:
                            self.logger.warning(f"API响应格式异常，IP: {ip_address}, 响应: {data}")
                            return None
                    except json.JSONDecodeError:
                        self.logger.warning(f"API响应JSON解析失败，IP: {ip_address}")
                        return None
                elif response.status_code == 401:
                    self.logger.error(f"API认证失败，IP: {ip_address}, 请检查共享密钥配置")
                    return None
                elif response.status_code == 403:
                    self.logger.error(f"API访问被拒绝，IP: {ip_address}, 可能是认证参数错误")
                    return None
                else:
                    self.logger.warning(f"API请求失败，IP: {ip_address}, 状态码: {response.status_code}")
                    try:
                        error_data = response.json()
                        self.logger.warning(f"错误详情: {error_data}")
                    except:
                        self.logger.warning(f"响应内容: {response.text[:200]}")
                    
            except requests.exceptions.Timeout:
                self.logger.warning(f"API请求超时，IP: {ip_address} (尝试 {attempt + 1}/{config.MAX_RETRIES})")
            except requests.exceptions.ConnectionError:
                self.logger.warning(f"连接失败，IP: {ip_address} (尝试 {attempt + 1}/{config.MAX_RETRIES})")
            except Exception as e:
                self.logger.error(f"API请求异常，IP: {ip_address}, 错误: {str(e)}")
                break
        
        self.logger.error(f"API请求最终失败，IP: {ip_address}")
        return None

    def process_user_data(self, all_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        处理用户数据：去重、排序、取前N名

        Args:
            all_data: 所有用户数据列表

        Returns:
            处理后的前N名用户数据
        """
        try:
            self.logger.info(f"开始处理用户数据，总计 {len(all_data)} 条记录")

            if not all_data:
                self.logger.warning("没有用户数据需要处理")
                return []

            # 创建DataFrame进行数据处理
            df = pd.DataFrame(all_data)

            # 确保total字段存在且为数值类型
            if 'total' not in df.columns:
                self.logger.error("用户数据中缺少'total'字段")
                return []

            # 转换total字段为数值类型
            df['total'] = pd.to_numeric(df['total'], errors='coerce')

            # 移除total为NaN的记录
            df = df.dropna(subset=['total'])

            # 按用户ID去重，保留total最大的记录
            if 'id' in df.columns:
                df = df.sort_values('total', ascending=False).drop_duplicates(subset=['id'], keep='first')
                self.logger.info(f"去重后剩余 {len(df)} 条记录")

            # 按total字段降序排序
            df = df.sort_values('total', ascending=False)

            # 取前N名
            top_users = df.head(config.TOP_N_USERS)

            self.logger.info(f"成功处理用户数据，获取前 {len(top_users)} 名用户")

            return top_users.to_dict('records')

        except Exception as e:
            self.logger.error(f"处理用户数据失败: {str(e)}")
            raise

    def create_output_excel(self, user_data: List[Dict[str, Any]], output_path: str):
        """
        创建输出Excel文件

        Args:
            user_data: 用户数据列表
            output_path: 输出文件路径
        """
        try:
            self.logger.info(f"开始创建Excel文件: {output_path}")

            if not user_data:
                self.logger.warning("没有数据可写入Excel文件")
                return

            # 创建DataFrame
            df = pd.DataFrame(user_data)

            # 定义输出列和中文表头
            column_mapping = {
                'id': '用户ID',
                'name': '用户名',
                'group': '用户组',
                'ip': 'IP地址',
                'up': '上行流量(MB)',
                'down': '下行流量(MB)',
                'total': '总流量(MB)',
                'session': '会话数',
                'status': '状态',
                'station_name': '局点',
                'source_ip': '设备IP'
            }

            # 选择需要输出的列
            output_columns = []
            output_headers = []

            for col, header in column_mapping.items():
                if col in df.columns:
                    output_columns.append(col)
                    output_headers.append(header)

            # 重新排列列顺序，将局点放在前面
            if 'station_name' in output_columns:
                output_columns.remove('station_name')
                output_columns.insert(0, 'station_name')
                output_headers.remove('局点')
                output_headers.insert(0, '局点')

            # 选择输出列
            output_df = df[output_columns].copy()
            output_df.columns = output_headers

            # 格式化数值列
            numeric_columns = ['上行流量(MB)', '下行流量(MB)', '总流量(MB)']
            for col in numeric_columns:
                if col in output_df.columns:
                    output_df[col] = pd.to_numeric(output_df[col], errors='coerce')
                    output_df[col] = output_df[col].round(2)

            # 写入Excel文件
            with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
                output_df.to_excel(
                    writer,
                    sheet_name=config.EXCEL_SHEET_NAME,
                    index=False,
                    startrow=0
                )

                # 获取工作表对象进行格式化
                worksheet = writer.sheets[config.EXCEL_SHEET_NAME]

                # 调整列宽
                for column in worksheet.columns:
                    max_length = 0
                    column_letter = column[0].column_letter
                    for cell in column:
                        try:
                            if len(str(cell.value)) > max_length:
                                max_length = len(str(cell.value))
                        except:
                            pass
                    adjusted_width = min(max_length + 2, 50)
                    worksheet.column_dimensions[column_letter].width = adjusted_width

            self.logger.info(f"Excel文件创建成功: {output_path}")

        except Exception as e:
            self.logger.error(f"创建Excel文件失败: {str(e)}")
            raise

    def run(self):
        """运行主流程"""
        try:
            self.logger.info("=" * 50)
            self.logger.info("用户流量统计脚本开始运行")
            self.logger.info("=" * 50)

            # 1. 读取Excel配置文件
            if not os.path.exists(config.INPUT_FILE_PATH):
                raise FileNotFoundError(f"输入文件不存在: {config.INPUT_FILE_PATH}")

            config_data = self.read_excel_config(config.INPUT_FILE_PATH)

            if not config_data:
                raise ValueError("没有读取到有效的配置数据")

            # 2. 调用API获取数据
            self.logger.info("开始调用API获取用户流量数据...")
            all_user_data = []

            for i, config_item in enumerate(config_data, 1):
                station_name = config_item['station_name']
                ip_address = config_item['ip_address']

                self.logger.info(f"处理第 {i}/{len(config_data)} 个设备: {station_name} ({ip_address})")

                user_data = self.call_api(ip_address)
                if user_data:
                    all_user_data.extend(user_data)
                    self.logger.info(f"从 {station_name} 获取到 {len(user_data)} 条用户数据")
                else:
                    self.logger.warning(f"从 {station_name} 未获取到数据")

            self.logger.info(f"API调用完成，总计获取 {len(all_user_data)} 条用户数据")

            # 3. 处理数据
            if not all_user_data:
                self.logger.warning("没有获取到任何用户数据，程序结束")
                return

            processed_data = self.process_user_data(all_user_data)

            # 4. 生成输出文件
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_filename = f"用户流量统计结果_{timestamp}.xlsx"
            output_path = os.path.join(config.OUTPUT_DIR, output_filename)

            self.create_output_excel(processed_data, output_path)

            # 5. 输出统计信息
            self.logger.info("=" * 50)
            self.logger.info("处理完成统计信息:")
            self.logger.info(f"处理设备数量: {len(config_data)}")
            self.logger.info(f"获取用户总数: {len(all_user_data)}")
            self.logger.info(f"输出用户数量: {len(processed_data)}")
            self.logger.info(f"输出文件路径: {output_path}")
            self.logger.info("=" * 50)

            print(f"\n✅ 处理完成！")
            print(f"📊 处理了 {len(config_data)} 个设备")
            print(f"👥 获取了 {len(all_user_data)} 条用户数据")
            print(f"🏆 输出前 {len(processed_data)} 名用户")
            print(f"📁 结果文件: {output_path}")

        except Exception as e:
            self.logger.error(f"程序运行失败: {str(e)}")
            print(f"\n❌ 程序运行失败: {str(e)}")
            raise


def main():
    """主函数"""
    try:
        processor = UserFlowStatsProcessor()
        processor.run()
    except KeyboardInterrupt:
        print("\n⚠️  程序被用户中断")
    except Exception as e:
        print(f"\n❌ 程序异常退出: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()
